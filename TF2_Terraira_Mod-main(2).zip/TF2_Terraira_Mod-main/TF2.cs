using Terraria.ModLoader;

namespace TF2
{
	public class TF2 : Mod
	{
	}
}