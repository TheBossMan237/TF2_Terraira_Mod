﻿using Terraria;
using Terraria.ModLoader;
namespace TF2
{
    public abstract class TF2Item : ModItem
    {

    }
}
