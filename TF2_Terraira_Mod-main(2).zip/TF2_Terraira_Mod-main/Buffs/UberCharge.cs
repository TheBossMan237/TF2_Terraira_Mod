﻿
namespace TF2.Buffs
{
    internal class UberCharge
    {
    }
}
